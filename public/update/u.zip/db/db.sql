UPDATE `news` SET `title` = 'test' WHERE `news`.`id` = 1;
