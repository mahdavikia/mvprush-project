-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 07, 2025 at 02:42 PM
-- Server version: 8.0.31
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvprush`
--

-- --------------------------------------------------------

--
-- Table structure for table `controller_banks`
--

DROP TABLE IF EXISTS `controller_banks`;
CREATE TABLE IF NOT EXISTS `controller_banks` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `controller_banks`
--

INSERT INTO `controller_banks` (`id`, `name`, `created_at`, `updated_at`, `title`) VALUES
(1, 'RoleController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'رول ها'),
(2, 'UserController', '2022-12-05 15:49:27', '2022-12-05 15:49:27', 'کاربران'),
(3, 'PermissionController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'دسترسی ها'),
(4, 'ProfileController', '2022-12-05 15:49:27', '2022-12-05 15:49:27', 'پروفایل ها'),
(22, 'ContentCatController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'دسته بندی ها'),
(21, 'LanguageController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'مدیریت زبان های محتوا'),
(23, 'ContentController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'مدیریت محتوا'),
(24, 'BookController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'کتاب ها'),
(25, 'PodcastController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'پادکست'),
(26, 'NewsController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'اخبار و رویداد'),
(27, 'ContactController', '2022-12-05 15:49:27', '2022-12-05 15:49:27', 'پیام ها'),
(28, 'SettingController', '2022-11-01 16:48:29', '2022-11-01 16:48:29', 'تنظیمات'),
(29, 'ShortcutController', '2023-05-06 10:10:09', '2023-05-06 10:10:09', 'میانبرهای داشبورد'),
(30, 'VersionController', '2023-05-06 17:29:08', '2023-05-06 17:29:08', 'نمایش نسخه ها'),
(31, 'AdminController', '2023-05-07 07:07:09', '2023-05-07 07:07:09', 'دسترسی های ادمین'),
(32, 'ChartController', '2023-05-09 10:24:18', '2023-05-09 10:24:18', 'تنظیمات نمودارها'),
(33, 'UserOptionController', '2022-11-02 00:18:29', '2023-05-06 13:40:09', 'تنظیمات مربوط به کاربر سیستم'),
(34, 'ChartOptionController', '2022-11-01 20:48:29', '2023-05-06 10:10:09', 'مدیریت نمودارها'),
(35, 'PlannerController', '2022-11-01 20:48:29', NULL, 'برنامه ریز شخصی'),
(36, 'MenuController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'مدیریت منوها'),
(37, 'GalleryController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'گالری'),
(38, 'ReportController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'گزارشات'),
(39, 'AzureController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'آژور'),
(40, 'ProductController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'محصولات و نسخه بندی'),
(41, 'ReportController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'گزارشات'),
(42, 'IframeController', '2022-11-01 16:48:29', '2023-05-06 06:10:09', 'گزارشهای آی فریم');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

DROP TABLE IF EXISTS `papers`;
CREATE TABLE IF NOT EXISTS `papers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `content_cat_id` bigint UNSIGNED NOT NULL,
  `title` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brief` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `title_en` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brief_en` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content_en` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `active` smallint NOT NULL DEFAULT '0',
  `expire_at` datetime DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `image` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contents_content_cat_id_foreign` (`content_cat_id`),
  KEY `contents_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parameters`
--

DROP TABLE IF EXISTS `parameters`;
CREATE TABLE IF NOT EXISTS `parameters` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parameters`
--

INSERT INTO `parameters` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'site_title', 'طراحی و پیاده سازی وب سایت و نرم افزارهای سفارشی | ترنج تک', '2023-03-06 14:00:28', '2023-07-01 00:47:54'),
(3, 'copyright', '', '2022-11-01 16:48:29', '2023-07-01 00:48:54'),
(4, 'site_description', 'توضیحات مربوط به این سایت در تگ سئو', '2023-03-18 01:41:07', '2023-03-18 01:41:07'),
(5, 'share_facebook', '#1', '2023-03-18 01:46:10', '2023-03-18 01:48:14'),
(6, 'share_telegram', '#2', '2023-03-18 01:46:23', '2023-03-18 01:46:23'),
(7, 'share_twitter', 'https://twitter.com/alirezakianpour', '2023-03-18 01:46:44', '2023-05-13 01:03:55'),
(8, 'share_linkedin', 'https://www.linkedin.com/in/kianpour/', '2023-03-18 01:47:14', '2023-05-13 00:47:56'),
(9, 'share_instagram', 'https://instagram.com/alireza_kianpour', '2023-03-18 01:47:39', '2023-05-13 01:03:18'),
(10, 'site_email', 'info@site.com', '2023-03-18 01:50:35', '2023-03-18 01:50:35'),
(11, 'site_contact', 'تماس با من', '2023-03-18 04:26:50', '2023-03-18 04:33:12');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` bigint UNSIGNED NOT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `role_id`, `title`, `route`, `created_at`, `updated_at`) VALUES
(1, 1, 'کامل رول ها', 'RoleController@full', '2023-01-26 06:29:06', '2023-01-26 06:29:06'),
(2, 1, 'لیست رول ها', 'RoleController@index', '2023-01-26 06:29:06', '2023-01-26 06:29:06'),
(3, 1, 'کامل کاربران', 'UserController@full', '2023-01-26 06:29:31', '2023-01-26 06:29:31'),
(4, 1, 'لیست کاربران', 'UserController@index', '2023-01-26 06:29:31', '2023-01-26 06:29:31'),
(5, 1, 'کامل دسترسی ها', 'PermissionController@full', '2023-01-26 06:29:37', '2023-01-26 06:29:37'),
(6, 1, 'لیست دسترسی ها', 'PermissionController@index', '2023-01-26 06:29:37', '2023-01-26 06:29:37'),
(7, 1, 'کامل پروفایل ها', 'ProfileController@full', '2023-01-26 06:29:43', '2023-01-26 06:29:43'),
(8, 1, 'لیست پروفایل ها', 'ProfileController@index', '2023-01-26 06:29:43', '2023-01-26 06:29:43'),
(82, 6, 'کامل آژور', 'AzureController@full', '2024-10-22 04:58:46', '2024-10-22 04:58:46'),
(16, 6, 'کامل پروفایل ها', 'ProfileController@full', '2023-01-26 09:20:25', '2024-10-22 04:58:40'),
(21, 1, 'دسترسی داشبورد', 'AdminController@dashboard', '2023-02-02 14:00:54', '2023-02-02 14:00:54'),
(20, 1, 'داشبورد ادمین', 'Global@dashboard', '2023-01-26 11:06:03', '2023-01-26 11:06:03'),
(22, 1, 'کامل مدیریت زبان های محتوا', 'LanguageController@full', '2023-02-02 14:13:46', '2023-02-02 14:13:46'),
(23, 1, 'لیست مدیریت زبان های محتوا', 'LanguageController@index', '2023-02-02 14:13:46', '2023-02-02 14:13:46'),
(24, 1, 'تنظیمات', 'Menu@setting', '2023-02-02 14:24:07', '2023-02-02 14:24:07'),
(30, 1, 'کامل دسته بندی ها', 'ContentCatController@full', '2023-02-04 01:51:11', '2023-02-04 01:51:11'),
(31, 1, 'لیست دسته بندی ها', 'ContentCatController@index', '2023-02-04 01:51:11', '2023-02-04 01:51:11'),
(32, 1, 'کامل مدیریت محتوا', 'ContentController@full', '2023-02-06 23:07:29', '2023-02-06 23:07:29'),
(33, 1, 'لیست مدیریت محتوا', 'ContentController@index', '2023-02-06 23:07:29', '2023-02-06 23:07:29'),
(34, 1, 'منوی دسته بندی کتاب ها', 'Menu@type_books', '2023-02-13 07:42:18', '2023-02-13 07:42:18'),
(35, 1, 'کامل کتاب ها', 'BookController@full', '2023-02-13 10:46:30', '2023-02-13 10:46:30'),
(36, 1, 'لیست کتاب ها', 'BookController@index', '2023-02-13 10:46:30', '2023-02-13 10:46:30'),
(37, 1, 'کامل پادکست', 'PodcastController@full', '2023-03-04 12:48:36', '2023-03-04 12:48:36'),
(38, 1, 'لیست پادکست', 'PodcastController@index', '2023-03-04 12:48:36', '2023-03-04 12:48:36'),
(39, 1, 'کامل اخبار و رویداد', 'NewsController@full', '2023-03-05 14:17:14', '2023-03-05 14:17:14'),
(40, 1, 'لیست اخبار و رویداد', 'NewsController@index', '2023-03-05 14:17:14', '2023-03-05 14:17:14'),
(41, 1, 'کامل تماس ها', 'ContactController@full', '2023-03-05 14:20:13', '2023-03-05 14:20:13'),
(42, 1, 'لیست تماس ها', 'ContactController@index', '2023-03-05 14:20:13', '2023-03-05 14:20:13'),
(43, 1, 'کامل پارامترها', 'ParameterController@full', '2023-03-06 14:00:21', '2023-05-13 00:46:30'),
(44, 1, 'لیست پارامترها', 'ParameterController@index', '2023-03-06 14:00:21', '2023-05-13 00:46:45'),
(46, 1, 'کامل میانبرهای داشبورد', 'ShortcutController@full', '2023-05-06 06:40:53', '2023-05-06 06:40:53'),
(47, 1, 'لیست میانبرهای داشبورد', 'ShortcutController@index', '2023-05-06 06:40:53', '2023-05-06 06:40:53'),
(48, 1, 'کامل نمایش نسخه ها', 'VersionController@full', '2023-05-06 14:00:25', '2023-05-06 14:00:25'),
(49, 1, 'لیست نمایش نسخه ها', 'VersionController@index', '2023-05-06 14:00:25', '2023-05-06 14:00:25'),
(50, 1, 'کامل دسترسی های ادمین', 'AdminController@full', '2023-05-07 03:37:51', '2023-05-07 03:37:51'),
(51, 1, 'لیست دسترسی های ادمین', 'AdminController@index', '2023-05-07 03:37:51', '2023-05-07 03:37:51'),
(52, 1, 'کامل تنظیمات نمودارها', 'ChartController@full', '2023-05-09 06:55:09', '2023-05-09 06:55:09'),
(53, 1, 'لیست تنظیمات نمودارها', 'ChartController@index', '2023-05-09 06:55:09', '2023-05-09 06:55:09'),
(54, 1, 'فعال یا غیرفعال سازی رکورد رول ها', 'RoleController@active', '2023-05-13 11:09:08', '2023-05-13 11:09:08'),
(55, 1, 'فعال یا غیرفعال سازی رکورد دسترسی ها', 'PermissionController@active', '2023-05-13 11:09:19', '2023-05-13 11:09:19'),
(56, 1, 'فعال یا غیرفعال سازی رکورد دسته بندی ها', 'ContentCatController@active', '2023-05-13 11:09:27', '2023-05-13 11:09:27'),
(57, 1, 'فعال یا غیرفعال سازی رکورد مدیریت محتوا', 'ContentController@active', '2023-05-13 11:09:33', '2023-05-13 11:09:33'),
(59, 1, 'فعال یا غیرفعال سازی رکورد کتاب ها', 'BookController@active', '2023-05-13 11:09:45', '2023-05-13 11:09:45'),
(60, 1, 'فعال یا غیرفعال سازی رکورد پادکست', 'PodcastController@active', '2023-05-13 11:09:57', '2023-05-13 11:09:57'),
(62, 1, 'فعال یا غیرفعال سازی رکورد اخبار و رویداد', 'NewsController@active', '2023-05-13 11:10:10', '2023-05-13 11:10:10'),
(63, 1, 'کامل تنظیمات مربوط به کاربر سیستم', 'UserOptionController@full', '2023-05-14 12:28:58', '2023-05-14 12:28:58'),
(64, 1, 'لیست تنظیمات مربوط به کاربر سیستم', 'UserOptionController@index', '2023-05-14 12:28:58', '2023-05-14 12:28:58'),
(65, 1, 'کامل مدیریت نمودارها', 'ChartOptionController@full', '2023-05-15 12:19:11', '2023-05-15 12:19:11'),
(66, 1, 'لیست مدیریت نمودارها', 'ChartOptionController@index', '2023-05-15 12:19:11', '2023-05-15 12:19:11'),
(69, 1, 'فعال یا غیرفعال سازی رکورد مدیریت نمودارها', 'ChartOptionController@active', '2023-05-17 06:21:51', '2023-05-17 06:21:51'),
(70, 1, 'کامل مدیریت منوها', 'MenuController@full', '2023-05-31 01:23:30', '2023-05-31 01:23:30'),
(71, 1, 'لیست مدیریت منوها', 'MenuController@index', '2023-05-31 01:23:30', '2023-05-31 01:23:30'),
(72, 1, 'فعال یا غیرفعال سازی رکورد مدیریت منوها', 'MenuController@active', '2023-05-31 02:01:41', '2023-05-31 02:01:41'),
(73, 1, 'کامل گالری', 'GalleryController@full', '2023-05-31 04:42:54', '2023-05-31 04:42:54'),
(74, 1, 'لیست گالری', 'GalleryController@index', '2023-05-31 04:42:54', '2023-05-31 04:42:54'),
(75, 1, 'فعال یا غیرفعال سازی رکورد گالری', 'GalleryController@active', '2023-05-31 04:42:54', '2023-05-31 04:42:54'),
(76, 1, 'کامل گزارشات', 'ReportController@full', '2023-06-10 01:55:03', '2023-06-10 01:55:03'),
(77, 1, 'لیست گزارشات', 'ReportController@index', '2023-06-10 01:55:03', '2023-06-10 01:55:03'),
(78, 1, 'کامل محصولات', 'ProductController@full', '2023-02-13 10:46:30', '2023-02-13 10:46:30'),
(79, 1, 'لیست محصولات', 'ProductController@index', '2023-02-13 10:46:30', '2023-02-13 10:46:30'),
(80, 1, 'فعال/غیرفعالسازی محصولات', 'ProductController@active', '2023-02-13 10:46:30', '2023-02-13 10:46:30'),
(81, 1, 'آژور', 'AzureController@full', '2024-10-22 03:51:01', '2024-10-22 03:51:01'),
(102, 6, 'لیست گزارشات', 'ReportController@index', '2024-10-27 00:55:12', '2024-10-27 00:55:12'),
(84, 6, 'لیست محصولات و نسخه بندی', 'ProductController@index', '2024-10-22 05:01:53', '2024-10-22 05:01:53'),
(85, 6, 'داشبورد', 'Global@dashboard', '2024-10-22 06:54:45', '2024-10-22 06:54:45'),
(86, 6, 'داشبورد کاربر', 'AdminController@dashboard', '2024-10-22 08:28:52', '2024-10-22 08:28:52'),
(87, 6, 'کامل نمایش نسخه ها', 'VersionController@full', '2024-10-22 08:43:38', '2024-10-22 08:43:38'),
(88, 6, 'لیست نمایش نسخه ها', 'VersionController@index', '2024-10-22 08:43:38', '2024-10-22 08:43:38'),
(89, 6, 'کامل پروفایل ها', 'ProfileController@full', '2024-10-22 08:43:53', '2024-10-22 08:43:53'),
(90, 6, 'لیست پروفایل ها', 'ProfileController@index', '2024-10-22 08:43:53', '2024-10-22 08:43:53'),
(91, 6, 'کامل پیام ها', 'ContactController@full', '2024-10-22 09:04:57', '2024-10-22 09:04:57'),
(92, 6, 'لیست پیام ها', 'ContactController@index', '2024-10-22 09:04:57', '2024-10-22 09:04:57'),
(93, 6, 'کامل کاربران', 'UserController@full', '2024-10-26 06:47:54', '2024-10-26 06:47:54'),
(94, 6, 'لیست کاربران', 'UserController@index', '2024-10-26 06:47:54', '2024-10-26 06:47:54'),
(100, 6, 'فرم ذخیره محصولات و نسخه بندی', 'ProductController@edit', '2024-10-26 08:26:04', '2024-10-26 08:26:04'),
(101, 6, 'کامل گزارشات', 'ReportController@full', '2024-10-27 00:55:12', '2024-10-27 00:55:12'),
(98, 6, 'نمایش محصولات و نسخه بندی', 'ProductController@show', '2024-10-26 08:23:38', '2024-10-26 08:23:38'),
(99, 6, 'بروزرسانی محصولات و نسخه بندی', 'ProductController@update', '2024-10-26 08:23:38', '2024-10-26 08:23:38'),
(103, 6, 'فرم ایجاد محصولات و نسخه بندی', 'ProductController@create', '2024-10-27 03:13:04', '2024-10-27 03:13:04'),
(104, 6, 'ایجاد محصولات و نسخه بندی', 'ProductController@store', '2024-10-27 03:13:04', '2024-10-27 03:13:04'),
(105, 6, 'کامل محصولات و نسخه بندی', 'ProductController@full', '2024-10-27 03:14:42', '2024-10-27 03:14:42'),
(106, 6, 'لیست محصولات و نسخه بندی', 'ProductController@index', '2024-10-27 03:14:42', '2024-10-27 03:14:42'),
(107, 1, 'کامل گزارشهای آی فریم', 'IframeController@full', '2025-05-12 06:22:01', '2025-05-12 06:22:01'),
(108, 1, 'فعال یا غیرفعال سازی رکورد گزارشهای آی فریم', 'IframeController@active', '2025-05-12 06:22:01', '2025-05-12 06:22:01'),
(109, 1, 'کامل تنظیمات', 'SettingController@full', '2025-05-14 07:37:57', '2025-05-14 07:37:57'),
(110, 6, 'لیست تنظیمات', 'SettingController@index', '2025-05-16 22:52:00', '2025-05-16 22:52:00'),
(111, 6, 'بروزرسانی تنظیمات', 'SettingController@update', '2025-05-16 22:52:00', '2025-05-16 22:52:00'),
(112, 6, 'فرم ذخیره تنظیمات', 'SettingController@edit', '2025-05-16 22:53:00', '2025-05-16 22:53:00');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
CREATE TABLE IF NOT EXISTS `profiles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profiles_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `firstname`, `lastname`, `avatar`, `created_at`, `updated_at`) VALUES
(1, 1, 'محمد', 'مهدوی کیا', 'avatar_1729435677.jpg', '2022-11-01 20:48:29', '2025-05-14 08:06:15');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `active`, `created_at`, `updated_at`, `title`) VALUES
(1, 'super', 1, '2022-12-05 11:13:38', '2023-01-26 05:56:36', 'سوپر ادمین'),
(6, 'user', 1, '2023-01-26 06:18:29', '2024-10-22 04:41:21', 'کاربر');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('owC7x7KE8dyDqRJXSY6iALjskrhHf5gonNQo3XNo', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YToxMTp7czo2OiJfdG9rZW4iO3M6NDA6ImVRY3IwWXhQMUwxNGFnNllyQ0dnS2RsMmptZUFZUU5XN3h1Uks0c0kiO3M6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYWRtaW4vdmVyc2lvbnMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MjI6ImdldF8xX0dsb2JhbEBkYXNoYm9hcmQiO2I6MTtzOjI3OiJnZXRfMV9JZnJhbWVDb250cm9sbGVyQGZ1bGwiO2I6MTtzOjI2OiJnZXRfMV9Vc2VyQ29udHJvbGxlckBpbmRleCI7YjoxO3M6Mjg6ImdldF8xX1NldHRpbmdDb250cm9sbGVyQGZ1bGwiO2I6MTtzOjMwOiJnZXRfMV9TaG9ydGN1dENvbnRyb2xsZXJAaW5kZXgiO2I6MTtzOjI3OiJnZXRfMV9Cb29rQ29udHJvbGxlckBhY3RpdmUiO2I6MTtzOjI3OiJnZXRfMV9Sb2xlQ29udHJvbGxlckBhY3RpdmUiO2I6MTt9', 1749275991);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(12, 'tabs_interval', '6000', '2025-05-14 07:38:50', '2025-06-03 02:27:08');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'محصولات تحت وب', '2024-10-26 16:34:38', '2024-10-26 16:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `team_id` int DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activated` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `team_id`, `email`, `email_verified_at`, `password`, `remember_token`, `activated`, `created_at`, `updated_at`, `role_id`) VALUES
(1, 1, 'mahdavikia.m@gmail.com', NULL, '25d55ad283aa400af464c76d713c07ad', NULL, 1, '2023-01-12 17:14:13', '2025-05-14 08:06:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

DROP TABLE IF EXISTS `user_logs`;
CREATE TABLE IF NOT EXISTS `user_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id`, `user_id`, `action_name`, `created_at`, `updated_at`) VALUES
(34, 1, 'ورود به سیستم', '2025-06-07 03:55:14', '2025-06-07 03:55:14');

-- --------------------------------------------------------

--
-- Table structure for table `user_options`
--

DROP TABLE IF EXISTS `user_options`;
CREATE TABLE IF NOT EXISTS `user_options` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_options_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_options`
--

INSERT INTO `user_options` (`id`, `user_id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 1, 'sidebar_theme', 'sidebar-dark', '2023-05-14 12:33:23', '2025-06-07 01:04:59');

-- --------------------------------------------------------

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
CREATE TABLE IF NOT EXISTS `versions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `versions`
--

INSERT INTO `versions` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '1.0', 'ریلیز اولیه سیستم', '2025-05-17 03:59:08', '2025-05-17 03:59:08');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
